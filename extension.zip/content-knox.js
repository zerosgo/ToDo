// content-knox.js
console.log('ToDo Syncer: Knox Content Script Loaded');

// Helper to wait
const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function scrapeAndSend() {
    try {
        console.log('ToDo Syncer: Starting sequence...');

        // 0. Initial Confirmation Page Check (New Requirement)
        // User provided info: A confirmation popup/page appears first.
        // Need to click button containing "Yonghee" or "이용희".

        let confirmBtn = null;
        // Search deeper for button-like elements including inputs of type button/submit
        const allElements = document.querySelectorAll('button, a, input[type="button"], input[type="submit"], div[role="button"], span');

        for (const el of allElements) {
            const txt = (el.value || el.textContent || '').trim();
            if (txt.includes('Yonghee') || txt.includes('이용희')) {
                confirmBtn = el;
                break;
            }
        }

        if (confirmBtn) {
            console.log('ToDo Syncer: Confirmation button found ("' + (confirmBtn.textContent || confirmBtn.value) + '"), clicking...');
            confirmBtn.click();
            // Wait for main calendar to load after clicking confirmation
            await wait(3000);
        } else {
            console.log('ToDo Syncer: No confirmation button found, checking for Agenda directly...');
        }

        // 1. Find 'Agenda' button. 
        // Strategy: Look for specific class or text content. 
        let agendaBtn = null;

        // Re-query elements as page structure might have changed
        const candidates = document.querySelectorAll('a, button, span, div[role="button"]');
        for (const el of candidates) {
            if (el.textContent.trim() === 'Agenda') {
                agendaBtn = el;
                break;
            }
        }

        if (agendaBtn) {
            console.log('ToDo Syncer: Agenda button found, clicking...');
            agendaBtn.click();

            // Wait for view update (AJAX)
            await wait(2000);
        } else {
            console.warn('ToDo Syncer: Agenda button NOT found. Proceeding with current view (might be Month view or already on Agenda)...');
        }

        // 2. Extract Text
        const allText = document.body.innerText;

        // 3. Try to parse Year/Month
        let year, month;
        const dateMatch = document.body.innerText.match(/(\d{4})[\.\- ]+(\d{1,2})/); // 2024. 01 or 2024-01
        if (dateMatch) {
            year = parseInt(dateMatch[1]);
            month = parseInt(dateMatch[2]) - 1; // 0-indexed
        }

        console.log('ToDo Syncer: Text extracted. Length:', allText.length);

        // 4. Send to Background
        chrome.runtime.sendMessage({
            action: 'DATA_SCRAPED',
            text: allText,
            year: year,
            month: month
        });

    } catch (e) {
        console.error('ToDo Syncer Error:', e);
    }
}

// Run when page loads
// Or wait a bit for dynamic load
setTimeout(scrapeAndSend, 3000);

// Also listen for manual trigger from popup
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'TRIGGER_SCRAPE') {
        scrapeAndSend();
    }
});
